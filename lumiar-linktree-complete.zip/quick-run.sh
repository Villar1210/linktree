#!/bin/bash
# ⚡ Scripts Rápidos - Lumiar Linktree

# Navegar para diretório correto
cd /var/www/linktree

# Ativar ambiente virtual
source venv/bin/activate

echo "🚀 Comandos rápidos para Lumiar Linktree"
echo "========================================"

case "$1" in
    "dev")
        echo "🔧 Executando em modo desenvolvimento..."
        export FLASK_ENV=development
        export FLASK_DEBUG=1
        python app.py
        ;;
        
    "prod")
        echo "🏭 Executando em modo produção..."
        export FLASK_ENV=production
        gunicorn --bind 127.0.0.1:5000 app:app
        ;;
        
    "daemon")
        echo "👥 Executando em modo daemon..."
        mkdir -p logs
        export FLASK_ENV=production
        gunicorn --bind 127.0.0.1:5000 \
                 --workers 4 \
                 --daemon \
                 --pid logs/gunicorn.pid \
                 --access-logfile logs/access.log \
                 --error-logfile logs/error.log \
                 app:app
        echo "✅ Aplicação rodando em background"
        echo "PID: $(cat logs/gunicorn.pid)"
        ;;
        
    "stop")
        echo "🛑 Parando aplicação..."
        # Parar systemd service se estiver rodando
        sudo systemctl stop linktree 2>/dev/null || true
        
        # Parar daemon se estiver rodando
        if [ -f "logs/gunicorn.pid" ]; then
            kill $(cat logs/gunicorn.pid) 2>/dev/null || true
            rm -f logs/gunicorn.pid
        fi
        
        # Forçar parada de todos os processos
        pkill -f "gunicorn.*app:app" 2>/dev/null || true
        pkill -f "python.*app.py" 2>/dev/null || true
        
        echo "✅ Aplicação parada"
        ;;
        
    "restart")
        echo "🔄 Reiniciando aplicação..."
        $0 stop
        sleep 2
        $0 daemon
        ;;
        
    "status")
        echo "📊 Status da aplicação:"
        
        # Verificar systemd
        if systemctl is-active --quiet linktree 2>/dev/null; then
            echo "✅ Systemd service: ATIVO"
        else
            echo "⚠️  Systemd service: INATIVO"
        fi
        
        # Verificar gunicorn
        if pgrep -f "gunicorn.*app:app" > /dev/null; then
            echo "✅ Gunicorn: RODANDO"
        else
            echo "⚠️  Gunicorn: PARADO"
        fi
        
        # Teste de conectividade
        if curl -s -f http://localhost:5000 > /dev/null 2>&1; then
            echo "✅ Aplicação: RESPONDENDO"
        else
            echo "❌ Aplicação: NÃO RESPONDE"
        fi
        ;;
        
    "logs")
        echo "📋 Últimos logs:"
        echo "==============="
        
        if [ -f "logs/error.log" ]; then
            echo "--- Logs de Erro ---"
            tail -20 logs/error.log
        fi
        
        if [ -f "logs/access.log" ]; then
            echo "--- Logs de Acesso ---"
            tail -10 logs/access.log
        fi
        
        # Logs do systemd se disponível
        if systemctl is-active --quiet linktree 2>/dev/null; then
            echo "--- Logs do Systemd ---"
            sudo journalctl -u linktree -n 10 --no-pager
        fi
        ;;
        
    "test")
        echo "🧪 Testando aplicação..."
        
        # Teste local
        echo "Testando localhost:5000..."
        if curl -s -f http://localhost:5000 > /dev/null; then
            echo "✅ localhost:5000 OK"
        else
            echo "❌ localhost:5000 FALHA"
        fi
        
        # Teste nginx
        echo "Testando através do nginx..."
        if curl -s -f http://localhost > /dev/null; then
            echo "✅ Nginx OK"
        else
            echo "❌ Nginx FALHA"
        fi
        
        # Teste subdomínio
        echo "Testando subdomínio..."
        if curl -s -f http://linktree.ivillar.com.br > /dev/null; then
            echo "✅ Subdomínio OK"
        else
            echo "❌ Subdomínio FALHA (verifique DNS)"
        fi
        ;;
        
    "install")
        echo "📦 Instalando/atualizando dependências..."
        pip install -r requirements.txt
        echo "✅ Dependências instaladas"
        ;;
        
    "backup")
        echo "💾 Criando backup dos dados..."
        backup_file="backup_$(date +%Y%m%d_%H%M%S).tar.gz"
        tar -czf $backup_file data/ static/ templates/ *.py *.txt *.md
        echo "✅ Backup criado: $backup_file"
        ;;
        
    *)
        echo "Uso: $0 {dev|prod|daemon|stop|restart|status|logs|test|install|backup}"
        echo ""
        echo "Comandos disponíveis:"
        echo "  dev      - Executar em modo desenvolvimento"
        echo "  prod     - Executar em modo produção (foreground)"
        echo "  daemon   - Executar em modo daemon (background)"
        echo "  stop     - Parar aplicação"
        echo "  restart  - Reiniciar aplicação"
        echo "  status   - Mostrar status"
        echo "  logs     - Mostrar logs"
        echo "  test     - Testar conectividade"
        echo "  install  - Instalar dependências"
        echo "  backup   - Criar backup"
        echo ""
        echo "Exemplos:"
        echo "  $0 dev      # Modo desenvolvimento"
        echo "  $0 daemon   # Produção em background"
        echo "  $0 status   # Ver status"
        ;;
esac