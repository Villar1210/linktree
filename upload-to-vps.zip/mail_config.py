# Configurações de e-mail para recuperação de senha
MAIL_SERVER = 'smtp.hostinger.com'
MAIL_PORT = 465
MAIL_USE_SSL = True
MAIL_USE_TLS = False
MAIL_USERNAME = 'recuperacao@ivillar.com.br'
MAIL_PASSWORD = 'Recuperacao@2025'
MAIL_DEFAULT_SENDER = 'recuperacao@ivillar.com.br'
