# 🔄 Como Reiniciar VPS via Painel Hostinger

## Passo a Passo:

### 1. Acessar Painel Hostinger
- Entre em: https://www.hostinger.com.br
- Faça login na sua conta
- Vá em "VPS" no menu

### 2. Localizar seu VPS
- Procure pelo VPS com IP: 72.61.41.119
- Clique no VPS para gerenciar

### 3. Reiniciar Servidor
- Procure botão "Restart" ou "Reiniciar"
- Clique e confirme o reinício
- Aguarde 3-5 minutos

### 4. Verificar se Voltou
Após reiniciar, teste:
- https://linktree.ivillar.com.br
- Deve carregar normalmente (não mais 502)

## Por que funciona?
- Reinicia todos os serviços automaticamente
- Limpa conexões travadas
- Resolve problemas de memória/processos

## Tempo estimado: 5 minutos