import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from mail_config import MAIL_SERVER, MAIL_PORT, MAIL_USE_SSL, MAIL_USERNAME, MAIL_PASSWORD, MAIL_DEFAULT_SENDER

